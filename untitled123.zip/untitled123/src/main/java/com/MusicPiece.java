package com;

public class MusicPiece {

    private int duration = 50 ;

    public MusicPiece() {

    }// Определение полей класса


    public int getDuration() {
        return duration;
    }// Конструктор по умолчанию класса

    public void setDuration(int duration) {
        this.duration = duration;
    }
} // Геттеры и сеттеры для полей класса