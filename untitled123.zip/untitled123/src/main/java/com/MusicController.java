package com;
// Объявление пакета для класса.
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
// Импорт необходимых классов из библиотек Spring Framework
@Controller
@RequestMapping("/music")
// Аннотация @Controller указывает на то, что этот класс является контроллером Spring.
// @RequestMapping определяет базовый URL-адрес для всех методов контроллера. Здесь указан путь "/music", поэтому все методы этого контроллера будут обрабатывать запросы, начинающиеся с "/music".
public class MusicController {
    // Объявление класса
    @RequestMapping(method = RequestMethod.GET)
    // Этот метод обрабатывает GET-запросы по адресу "/music".
    public String showMusic(ModelMap model) {
        MusicCarrier musicCarrier = new MusicCarrier();
        MusicPiece musicPiece = new MusicPiece();
        // Создание объектов
        model.addAttribute("musicCarrier", musicCarrier);
        model.addAttribute("musicPiece", musicPiece);
        // Добавление атрибутов "musicCarrier" и "musicPiece" в объект ModelMap.
// Это позволит представлению получить доступ к этим объектам.
        return "music";
        // Возвращает имя представления "music"
    }
}
