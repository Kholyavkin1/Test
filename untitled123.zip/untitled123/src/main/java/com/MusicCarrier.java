package com;

public class MusicCarrier {
    private String name = "Корж";
    private String ownerFullName = "Максим Коржов";
    private String album = "Лето 2015";
    private String artist = "Коржов";
    private String genre = "Поп";
    private int releaseYear = 2015;
// Определение полей класса MusicCarrier

    public MusicCarrier() {

    }
    // Конструктор по умолчанию класса
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOwnerFullName() {
        return ownerFullName;
    }

    public void setOwnerFullName(String ownerFullName) {
        this.ownerFullName = ownerFullName;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(String album) {
        this.album = album;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }
    // Геттеры и сеттеры для полей класса
}

